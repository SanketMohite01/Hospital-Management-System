package HospitalManagementSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
    private static Connection connection;

    public static Connection getConnection() {
        if (connection == null) {
            try {
                // Replace these values with your actual database credentials
                String url = "jdbc:mysql://localhost:3306/hospital";
                String username = "root";
                String password = "SQL1234";

                connection = DriverManager.getConnection(url, username, password);
                System.out.println("Database connected successfully.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return connection;
    }
}

